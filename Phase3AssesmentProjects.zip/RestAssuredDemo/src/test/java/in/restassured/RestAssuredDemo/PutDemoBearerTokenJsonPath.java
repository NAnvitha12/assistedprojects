package in.restassured.RestAssuredDemo;

import java.util.HashMap;

import org.junit.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PutDemoBearerTokenJsonPath {
	HashMap<String,String>map=new HashMap<String,String>();
	@BeforeMethod
	public void payLoad() {
		map.put("name","anvitha");

		map.put("email","ani1112222223@gmail.com");
		map.put("gender","female");
		map.put("status","active");

		RestAssured.baseURI="https://gorest.co.in/";
		RestAssured.basePath="/public/v2/users/4495043";
		
	}
	@Test
	public void updateResource() {
		Response response =RestAssured
		.given()
		.contentType("application/json")
		.header("Authorization","Bearer 49c69bcde74a7f84ec5a0020321939a6d643f0052a2d438a056760e5335ff446")

		.body(map)
		.when()
		.put()
		.then()
		.extract().response();
		JsonPath jsonPath=response.jsonPath();
		//System.out.println(jsonPath.get("name").toString());
		Assert.assertTrue(jsonPath.get("name").toString().equals("anvitha"));
	}
}
