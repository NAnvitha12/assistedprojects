package in.restassured.RestAssuredDemo;

import java.util.HashMap;
import java.util.UUID;
import org.junit.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.is;
public class CreateUpdateDeleteResource extends TestBase {
	HashMap<String, String> map = new HashMap<String, String>();
	UUID uuid = UUID.randomUUID();
	int id;
	JsonPath jsonPath;

	@Test(priority=0)
	public void payLoad() {
		map.put("name", "captanPlanet");
  map.put("email", uuid + "@gmail.com");
		map.put("gender", "female");
		map.put("status", "active");

		RestAssured.baseURI = "https://gorest.co.in/";
		RestAssured.basePath = "/public/v2/users";
logger.info("payload created");
	}
	@Test(priority=1)
	public void createResource() {
		Response response=RestAssured
		.given()
		.contentType("application/json")
		.body(map)
		.header("Authorization","Bearer 49c69bcde74a7f84ec5a0020321939a6d643f0052a2d438a056760e5335ff446")
		.when()
		.post()
		.then()
		.extract().response();
		logger.info("resource created sucessfully");

		 jsonPath=response.jsonPath();
		id=jsonPath.get("id");
		System.out.println("id");
	}
	@Test(priority=2)
	public void verifyResource() {
		RestAssured
		.given()
		.contentType("application/json")
		
		.header("Authorization","Bearer 49c69bcde74a7f84ec5a0020321939a6d643f0052a2d438a056760e5335ff446")
		.when()
		.get("https://gorest.co.in/public/v2/users/"+id)
		.then()
		
		.statusCode(200);
		logger.info("resource verified sucessfully");

		Assert.assertTrue(jsonPath.get("name").toString().equals("captanPlanet"));
		
	}
	
	@Test(priority = 3)
	public void updateResource() {
		map.put("name", "captanPlanett");
		  map.put("email", uuid + "@gmail.com");
				map.put("gender", "female");
				map.put("status", "active");

				RestAssured.baseURI = "https://gorest.co.in/";
				RestAssured.basePath = "/public/v2/users/"+ id;
	
		RestAssured
		.given()
		.contentType("application/json")
		.header("Authorization","Bearer 49c69bcde74a7f84ec5a0020321939a6d643f0052a2d438a056760e5335ff446")

		.body(map)
		.when()
		.put()
		.then()
		.statusCode(200)
		
		.assertThat()
		.body("name",is("captanPlanett"));
		logger.info("resource updated sucessfully");

		}
	@Test(priority = 4)
	public void deleteResource() {
	    RestAssured
	        .given()
	        .contentType("application/json")
	        .header("Authorization", "Bearer 49c69bcde74a7f84ec5a0020321939a6d643f0052a2d438a056760e5335ff446")
	        .when()
	        .delete("https://gorest.co.in/public/v2/users/" + id)
	        .then()
	        .statusCode(204); // 204 No Content indicates successful deletion
			logger.info("resource deleted sucessfully");
	}

	}

