package in.restassured.RestAssuredDemo;

import java.util.HashMap;
import java.util.UUID;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class BearerTokenDemo {
	UUID uuid=UUID.randomUUID();
	HashMap<String,String>map=new HashMap<String,String>();
	@BeforeMethod
	public void payLoad() {
		map.put("name","Batman");

		map.put("email",uuid+"@gmail.com");
		map.put("gender","female");
		map.put("status","active");

		RestAssured.baseURI="https://gorest.co.in/";
		RestAssured.basePath="/public/v2/users";
		
	}
	@Test
	public void createResource() {
		RestAssured
		.given()
		.contentType("application/json")
		.body(map)
		.header("Authorization","Bearer 49c69bcde74a7f84ec5a0020321939a6d643f0052a2d438a056760e5335ff446")
		.when()
		.post()
		.then()
		.statusCode(201)
		.log().all();
	}
}
