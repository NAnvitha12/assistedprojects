package in.restassured.RestAssuredDemo;

import java.util.HashMap;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class PutDemo {
HashMap<String,String>map=new HashMap<String,String>();
	@BeforeMethod
	public void payLoad() {
		map.put("name","Anvitha");

		map.put("job","programmer");
		RestAssured.baseURI="https://reqres.in/";
		RestAssured.basePath="/api/users/903";
		
	}
	@Test
	public void updateResource() {
		RestAssured
		.given()
		.contentType("application/json")
		.body(map)
		.when()
		.post()
		.then()
		.statusCode(201).log().all();
	}
}
