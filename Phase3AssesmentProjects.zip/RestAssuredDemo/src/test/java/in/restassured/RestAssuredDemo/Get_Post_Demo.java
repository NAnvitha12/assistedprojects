package in.restassured.RestAssuredDemo;

import java.util.HashMap;
import java.util.UUID;
import org.junit.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.is;

public class Get_Post_Demo extends TestBase {
	HashMap<String, String> map = new HashMap<String, String>();
	String id;
	JsonPath jsonPath;

	@Test(priority = 0)
	public void payLoad() {
		map.put("name", "morpheus");
		map.put("job", "leader");
		RestAssured.baseURI = "https://reqres.in/";
		RestAssured.basePath = "/api/users";
		logger.info("payload created");
	}

	@Test(priority = 1)
	public void createResource() {
		Response response = RestAssured.given().contentType("application/json").body(map)
				.header("Authorization", "Bearer 49c69bcde74a7f84ec5a0020321939a6d643f0052a2d438a056760e5335ff446")
				.when().post().then().extract().response();
		logger.info("resource created sucessfully");

		jsonPath = response.jsonPath();
		id = jsonPath.get("id");
		System.out.println("id");
	}

	@Test(priority = 2)
	public void verifyResource() {
		RestAssured.given().contentType("application/json")

				.header("Authorization", "Bearer 49c69bcde74a7f84ec5a0020321939a6d643f0052a2d438a056760e5335ff446")
				.when().get("https://reqres.in/api/users?"+id).then()

				.statusCode(200);
		logger.info("resource verified sucessfully");

		Assert.assertTrue(jsonPath.get("name").toString().equals("morpheus"));

	}

}