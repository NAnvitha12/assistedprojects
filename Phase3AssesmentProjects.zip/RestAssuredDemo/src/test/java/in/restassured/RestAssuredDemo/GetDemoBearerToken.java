package in.restassured.RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class GetDemoBearerToken {
@Test
public void verifyResource() {
	RestAssured
	.given()
	.contentType("application/json")
	.header("Authorization","Bearer 49c69bcde74a7f84ec5a0020321939a6d643f0052a2d438a056760e5335ff446")
	.when()
	.get("https://gorest.co.in/public/v2/users/4495043")
	.then().statusCode(200)
	.log().all();
	
	
}
}
