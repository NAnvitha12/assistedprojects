package in.restassured.RestAssuredDemo;

import org.junit.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class GetDemo2 {
	@Test
	public void verifyResource() {
		RestAssured
		.given()
		.contentType("application/json")
		
		.header("Authorization","Bearer 49c69bcde74a7f84ec5a0020321939a6d643f0052a2d438a056760e5335ff446")
		.when()
		.get("https://reqres.in/api/users/2")
		.then()
		
		.statusCode(200)
		.log().all();
	}
}
