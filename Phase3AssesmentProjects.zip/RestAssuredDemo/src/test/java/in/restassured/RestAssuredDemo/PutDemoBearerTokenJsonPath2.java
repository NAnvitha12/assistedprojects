package in.restassured.RestAssuredDemo;


import org.junit.Assert;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PutDemoBearerTokenJsonPath2 {

	@Test
	public void verifuCurrencyName() {
		Response response =RestAssured
				.when()
	.get("https://restcountries.com/v3.1/name/jordan")
		.then()
		.extract().response();
		JsonPath jsonPath=response.jsonPath();
		//System.out.println(jsonPath.get("name").toString());
		Assert.assertTrue(jsonPath.get("[0].currencies.JOD.name").toString().equals("Jordanian dinar"));
	}
}
