package in.restassured.RestAssuredDemo;

import java.util.UUID;

public class UUIDDemo {
UUID uuid=UUID.randomUUID();
}
