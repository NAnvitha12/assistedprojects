package in.restassured.RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class APIKeyDemo {
@Test
public void getWeatherInfo() {
	RestAssured
	.given()
	.param("q", "guntur")
	.param("appid", "a0128e93087e260d0e44fc4dd3790cc7")
	.when()
	.get("https://api.openweathermap.org/data/2.5/weather")
	.then()
	.statusCode(200)
	.log().all();
}
}
