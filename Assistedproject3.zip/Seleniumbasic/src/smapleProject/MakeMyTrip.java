package smapleProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

public class MakeMyTrip {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\anji\\Downloads\\chromedriver_win32\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.makemytrip.com");
		driver.findElement(By.xpath("//span[contains(@class,'chNavIcon appendBottom2 chSprite chFlights active')]"))
				.click();
		driver.findElement(By.xpath("(//span[contains(@class,'lbl_input appendBottom10')])[1]")).click();
		driver.findElement(
				By.xpath("//input[contains(@class,'react-autosuggest__input react-autosuggest__input--open')]"))
				.sendKeys("Mumbai");

		driver.findElement(By.xpath("//p[contains(text(),'Mumbai, India')]")).click();

		driver.findElement(By.xpath("(//span[contains(@class,'lbl_input appendBottom10')])[2]")).click();
		driver.findElement(By.xpath("//input[contains(@placeholder,'To')]")).sendKeys("Hyderabad");
		driver.findElement(By.xpath("//p[contains(text(),'Hyderabad, India')]")).click();

	
		driver.findElement(By.xpath("(//span[contains(@class,'lbl_input appendBottom10')])[3]")).click();
		Thread.sleep(5000);

		String flag = "False";

		while (flag == "False") {

			if (driver.findElements(By.xpath("//div[contains(@aria-label,'Sat Jul 22 2023')]")).size() > 0) {

				driver.findElement(By.xpath("//div[contains(@aria-label,'Sat Jul 22 2023')]")).click();
				flag = "True";
				Thread.sleep(5000);
			}

			else {
				Thread.sleep(5000);
				driver.findElement(By.xpath("//span[@class='DayPicker-NavButton DayPicker-NavButton--next']")).click();
			}

		}

		System.out.println("Test case is passed");
		driver.findElement(By.xpath("(//span[contains(@class,'lbl_input appendBottom10')])[4]")).click();
		Thread.sleep(5000);

		String flag1 = "False";

		while (flag1 == "False") {

			if (driver.findElements(By.xpath("//div[contains(@aria-label,'Sat Jul 29 2023')]")).size() > 0) {

				driver.findElement(By.xpath("//div[contains(@aria-label,'Sat Jul 29 2023')]")).click();
				flag1 = "True";
				Thread.sleep(5000);
			}

			else {
				Thread.sleep(5000);
				driver.findElement(By.xpath("//span[@class='DayPicker-NavButton DayPicker-NavButton--next']")).click();
			}

		}

		System.out.println("Test case is passed");

		driver.findElement(By.xpath("//a[contains(@class,'primaryBtn font24 latoBold widgetSearchBtn')]")).click();
		//driver.findElement(By.xpath("//button[contains(@class,'button buttonPrimary buttonBig fontSize14')]")).click();
		driver.findElement(By.xpath("//span[contains(@class,'bgProperties icon20 overlayCrossIcon')]")).click();

		// driver.findElement(By.xpath("//button[contains(@class,'button buttonSecondry
		// buttonBig fontSize12 relative')]")).click();
		driver.findElement(By.xpath("(//span[contains(@class,'outer')])[1]")).click();
		driver.findElement(
				By.xpath("//button[contains(@class,'splitFooterButton button buttonPrimary buttonBig appendBottom8')]"))
				.click();
		driver.findElement(By.xpath("//button[contains(@class,'buttonPrimary buttonBig  lato-black button' )]"))
				.click();
		
		driver.close();

	}
}