package com.na.webelements.demo1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButtonAndCheckBoxes {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://letcode.in/radio");
		driver.findElement(By.id("yes")).click();
		driver.findElement(By.id("one")).click();
		driver.findElement(By.id("bug")).click();
		driver.findElement(By.id("foo")).click();

		driver.findElement(By.xpath("(//input[contains(@type,'checkbox')])[1]")).click();

		driver.findElement(By.xpath("(//input[contains(@type,'checkbox')])[2]")).click();
		driver.findElement(By.xpath("(//input[contains(@type,'checkbox')])[1]")).click();

		driver.quit();
	}

}
