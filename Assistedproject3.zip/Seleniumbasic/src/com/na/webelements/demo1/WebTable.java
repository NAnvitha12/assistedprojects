package com.na.webelements.demo1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTable {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://letcode.in/table");
		//sum up all the prices shown in the table verify it should be equals to 858
		WebElement firstTable=driver.findElement(By.id("shopping"));
		//capture all the rows of table put them into a list
		List<WebElement> rows =firstTable.findElements(By.tagName("tr"));
		//from each row capture all the td elements in aseparate list and then the 2nd td element
		//from the new list
		int sum=0;
		for(int i=1;i<rows.size();i++) {
			WebElement row=rows.get(i);
			List<WebElement> columns=row.findElements(By.tagName("td"));
			int price=Integer.parseInt(columns.get(1).getText());
			sum=sum+price;
			
		}
		int expectedSum=858;
		if(expectedSum==sum) {
			System.out.println("test case passed");
		}else {
			System.out.println("test case failed");
		}
		driver.quit();
	}

}
