package demo;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class FileUpload {

	public static void main(String[] args) throws InterruptedException, IOException {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		WebElement button = driver.findElement(By.xpath("//input[contains(@id,'imagesrc')]"));
		Actions act = new Actions(driver);
		act.moveToElement(button).click().perform();
		Runtime.getRuntime().exec("C:\\Users\\anji\\Desktop\\FileUpload.exe" + " " + "C:\\Users\\anji\\Desktop\\controller.txt");
		driver.close();
	}

}
