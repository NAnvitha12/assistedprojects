package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JdbcSelectSelenium {

	public static void main(String[] args) throws SQLException {
		// Establish JDBC database connection
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/animated_movies?useSSL=false",
				"root", "root");
		Statement statement = connection.createStatement();

		// Execute a select query on the movies table
		String selectQuery = "SELECT * FROM movies";
		ResultSet resultSet = statement.executeQuery(selectQuery);

		// Process the results
		while (resultSet.next()) {
			int movie_id = resultSet.getInt("movie_id");
			String title = resultSet.getString("title");
			String genre = resultSet.getString("genre");
			String director = resultSet.getString("director");
			int release_year = resultSet.getInt("release_year");

			// Print the retrieved data
			System.out.println("Movie ID: " + movie_id);
			System.out.println("Title: " + title);
			System.out.println("Genre: " + genre);
			System.out.println("Director: " + director);
			System.out.println("Year: " + release_year);
			System.out.println("----------------------");
		}

		// Close the JDBC connection and result set
		resultSet.close();
		connection.close();

		// Perform Selenium WebDriver actions
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\anji\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.example.com");
		WebElement element = driver.findElement(By.tagName("h1"));
		String text = element.getText();
		System.out.println("Page title: " + text);
		driver.close();

		System.out.println("Program Executed");

	}

}
