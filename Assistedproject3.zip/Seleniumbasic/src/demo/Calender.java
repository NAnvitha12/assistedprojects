package demo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Calender {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\anji\\Downloads\\chromedriver_win32\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.expedia.co.in/");
		// click on calender icon
		driver.findElement(By.id("date_form_field-btn")).click();
		// select 9th month from the next month
		WebElement nextmonth = driver.findElement(By.xpath("(//table[contains(@class,'weeks')])[2]"));
		List<WebElement> rows = nextmonth.findElements(By.tagName("tr"));
		for (int i = 1; i < rows.size(); i++) {
			WebElement row = rows.get(i);
			List<WebElement> columns = row.findElements(By.tagName("button"));
			for (WebElement x : columns) {
				if (x.getAttribute("data-day").equals("19")) {
					x.click();
					// stop searching rest of dates by coming out of the for each-loop
					break;
				}

			}
		}
		// click on done to close the calender
		driver.findElement(By.xpath("//button[contains(@data-stid,'apply-date')]")).click();
	}

}
