package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JDBCSeleniumExample {
    public static void main(String[] args) throws SQLException {
        // Establish JDBC database connection
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/servlet_basedapplication?useSSL=false", "root", "root");
        Statement statement = connection.createStatement();
        
        // Insert a record into the products table
        String insertQuery = "INSERT INTO products VALUES (1, 'Product 1', 19.99, 'Description for Product A');";
        
        statement.execute(insertQuery);
        
        // Close the JDBC connection
        connection.close();
        
        // Perform Selenium WebDriver actions
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\anji\\Downloads\\chromedriver_win32\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        
        // Your Selenium WebDriver code here
        driver.get("https://www.example.com");
        WebElement element = driver.findElement(By.tagName("h1"));
        String text = element.getText();
        System.out.println("Page title: " + text);
        
        // Quit the WebDriver
        driver.quit();
        
        System.out.println("Program Executed");
    }
}
