package demo;

import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyTitle {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		// navigate to appilication
		driver.get("https://www.facebook.com/");
		// verify the visitors on the page
		String expectedTitle = "Facebook – log in or sign up";
		String actualTitle = driver.getTitle();
		System.out.println(expectedTitle);
		System.out.println(actualTitle);
		if (expectedTitle.equals(actualTitle)) {
			System.out.println("test case passed");
		} else {
			System.out.println("test case failed");
		}
		driver.quit();
	}

}
