package com.na.jdbc.ex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdateQuery {

	public static void main(String[] args) throws SQLException {
		String dbUrl = "jdbc:mysql://localhost:3306/animated_movies?useSSL=false";
		String userName = "root";
		String password = "root";
		String query = "UPDATE movies SET director = 'anvitha',release_year=2013 WHERE movie_id = 4";
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(dbUrl, userName, password);
			Statement statement = con.createStatement();
			statement.executeUpdate(query);
			System.out.println("record updated sucessfully");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.close();
		}

	}

}
