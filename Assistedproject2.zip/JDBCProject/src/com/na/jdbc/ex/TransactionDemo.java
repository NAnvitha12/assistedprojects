package com.na.jdbc.ex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TransactionDemo {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/bank_accounts?useSSL=false";
    private static final String JDBC_USERNAME = "root";
    private static final String JDBC_PASSWORD = "root";

    public static void main(String[] args) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);

            // Start the transaction
            connection.setAutoCommit(false);

            // Withdraw money from Account A
            updateBalance(connection, 101, -500.0);

            // Deposit money into Account B
            updateBalance(connection, 102, 500.0);

            // If everything is successful, commit the transaction
            connection.commit();
            System.out.println("Transaction completed successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // If any error occurs, rollback the transaction
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
            System.out.println("Transaction failed. Rolled back changes.");
        } finally {
            try {
                if (connection != null) {
                    connection.setAutoCommit(true); // Reset auto-commit to true
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void updateBalance(Connection connection, int accountNumber, double amount) throws SQLException {
        String sql = "UPDATE bank_accounts SET balance = balance + ? WHERE account_number = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setDouble(1, amount);
        statement.setInt(2, accountNumber);
        statement.executeUpdate();
        statement.close();
    }
}
