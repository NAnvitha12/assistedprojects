package com.na.jdbc.ex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertQuery {

	public static void main(String[] args) throws SQLException {
		String dbUrl = "jdbc:mysql://localhost:3306/animated_movies?useSSL=false";
		String userName = "root";
		String password = "root";
		String query = "INSERT INTO movies VALUE(4,'findingnemo','comedy-drama','andrewstanton',2003)";
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(dbUrl, userName, password);
			Statement statement = con.createStatement();
			statement.executeUpdate(query);
			System.out.println("record inserted sucessfully");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.close();
		}
	}
}
