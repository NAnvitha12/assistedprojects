package com.na.jdbc.ex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDataBase {

	public static void main(String[] args) throws SQLException {
		String dbUrl = "jdbc:mysql://localhost:3306?useSSL=false";
		String userName = "root";
		String password = "root";
		String query = "Create Database action_movies";
		Connection con = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(dbUrl, userName,password);
			Statement statement = con.createStatement();
			statement.execute(query);
	}catch(Exception e) {
		System.out.println(e.getMessage());
	}finally {
		con.close();
	}
	}
}
