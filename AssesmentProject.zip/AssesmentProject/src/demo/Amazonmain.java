package demo;

import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Amazonmain {

	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver = new ChromeDriver();
		// driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		driver.findElement(By.linkText("Mobiles")).click();

		WebElement mobile = driver.findElement(By.linkText("Mobiles & Accessories"));

		Actions actions = new Actions(driver);
		actions.moveToElement(mobile).build().perform();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Apple")));
		driver.findElement(By.linkText("Apple")).click();
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Iphone 13");
		driver.findElement(By.xpath("//*[@id='nav-search-submit-button']")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 1000)");

		// Find the element to click
		WebElement flag = driver.findElement(By.linkText("Apple iPhone 13 Mini (512GB) - Midnight"));

		// Scroll to the element
		js.executeScript("arguments[0].scrollIntoView();", flag);

		// Click the element
		flag.click();

		// Pause for a few seconds to allow time for the click action
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());

		driver.switchTo().window(tabs.get(1));
		Thread.sleep(60);
		driver.findElement(By.id("buy-now-button")).click();
		// driver.findElement(By.xpath("//input[contains(@id,'buy-now-button')]")).click();
		driver.quit();

	}

}
