package sampleProject;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class VerifyTitle {
	ChromeDriver driver;
	 @BeforeClass
	 public void SetUp() {
		 driver = new ChromeDriver();
		// navigate to appilication
		driver.get("https://www.facebook.com/");
	 }
		// verify the visitors on the page
		@Test
		public void VerifyTitle() {
		String expectedTitle = "Facebook – log in or sign up";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, expectedTitle);
		}
		@AfterTest
		public void Close() {
		driver.quit();
		}

}
