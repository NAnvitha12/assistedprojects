package com.simplilearn.JUnitdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductsPage {
    private final WebDriver driver;

    private final By addToCartButton = By.id("add-to-cart-sauce-labs-backpack");
    private final By cartIcon = By.cssSelector("#shopping_cart_container > a");
    private final By checkOut= By.id("checkout");

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void addFirstProductToCart() {
        driver.findElement(addToCartButton).click();
    }
    public void goToCart() {
        driver.findElement(cartIcon).click();
    }
    public void checkOut() {
    	driver.findElement(checkOut).click();
    }
}