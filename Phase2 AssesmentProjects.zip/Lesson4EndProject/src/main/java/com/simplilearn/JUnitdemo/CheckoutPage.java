package com.simplilearn.JUnitdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
	private final WebDriver driver;

	private final By firstNameField = By.xpath("//input[contains(@id,'first-name')]");
	private final By lastNameField = By.xpath("//input[contains(@id,'last-name')]");
	private final By zipCodeField = By.xpath("//input[contains(@id,'postal-code')]");
	private final By continueButton = By.name("continue");
	 private final By finishButton = By.name("finish");

	public CheckoutPage(WebDriver driver) {
		this.driver = driver;
	}

	public void enterFirstName(String firstName) {

		driver.findElement(firstNameField).sendKeys(firstName);
		;

	}

	public void enterLastName(String lastName) {
		driver.findElement(lastNameField).sendKeys(lastName);
	}

	public void enterZipCode(String zipCode) {
		driver.findElement(zipCodeField).sendKeys(zipCode);
	}

	public void continueToOverview() {
		driver.findElement(continueButton).click();
	}

	public void finishOrder() {
		driver.findElement(finishButton).click();
	}

}