package project;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.simplilearn.JUnitdemo.CheckoutPage;
import com.simplilearn.JUnitdemo.LoginPage;
import com.simplilearn.JUnitdemo.ProductsPage;

public class SauceDemoTest {
	private WebDriver driver;

	@BeforeClass
	public void setup() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.saucedemo.com/");
	}

	@Test
	public void testSauceDemo() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUsername("standard_user");
		loginPage.enterPassword("secret_sauce");
		loginPage.clickLoginButton();

		ProductsPage ProductsPage = new ProductsPage(driver);
		ProductsPage.addFirstProductToCart();
		ProductsPage.goToCart();
		ProductsPage.checkOut();

		CheckoutPage checkoutPage = new CheckoutPage(driver);
		checkoutPage.enterFirstName("John");
		checkoutPage.enterLastName("Doe");
		checkoutPage.enterZipCode("12345");
		checkoutPage.continueToOverview();
		checkoutPage.finishOrder();
	}

}
