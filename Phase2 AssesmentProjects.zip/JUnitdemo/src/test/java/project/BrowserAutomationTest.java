package project;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserAutomationTest {

	static WebDriver driver;

	@BeforeClass
	public static void setUp() { // Mark the method as static
		// Create a new instance of ChromeDriver
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\anji\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Test
	public void testGoogleSearch() {
		// Open Google homepage
		driver.get("https://www.google.com");

		// Find the search input element and enter a search term
		driver.findElement(By.name("q")).sendKeys("maven repository");

		// Submit the form
		driver.findElement(By.name("q")).submit();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// Check if the title of the search results page contains the search term
		String pageTitle = driver.getTitle();
		System.out.println("test case is passed");
		assertEquals("maven repository - Google Search", pageTitle);
	}

	@Test
	public void testErrormsg() {
		driver.get("https://www.facebook.com/");

		driver.findElement(By.id("email")).sendKeys("batman554466@gmail.com");
		driver.findElement(By.id("pass")).sendKeys("password@123");
		driver.findElement(By.name("login")).click();

		String expectedErrMsg = "The email address you entered isn't connected to an account. Find your account and log in.";
		String actualErrMsg = driver.findElement(By.xpath("(//div[contains(@class,'ay')])[3]")).getText();
		System.out.println("test case is passed");
		Assert.assertEquals(expectedErrMsg, actualErrMsg);
	}

	@AfterClass
	public static void tearDown() { // Mark the method as static
		// Close the browser after each test
		driver.quit();
	}
}
