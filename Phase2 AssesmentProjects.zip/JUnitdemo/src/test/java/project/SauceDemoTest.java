package project;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.simplilearn.JUnitdemo.CartPage;
import com.simplilearn.JUnitdemo.CheckoutPage;
import com.simplilearn.JUnitdemo.LoginPage;
import com.simplilearn.JUnitdemo.OverviewPage;
import com.simplilearn.JUnitdemo.ProductsPage;

public class SauceDemoTest {
    private WebDriver driver;

    @BeforeEach
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
    }

    @AfterEach
    public void tearDown() {
        driver.quit();
    }

    @Test
    public void testSauceDemo() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("standard_user", "secret_sauce");

        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addFirstProductToCart();
        productsPage.goToCart();

        CartPage cartPage = new CartPage(driver);
        cartPage.checkout();

        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.enterDetails("John", "Doe", "12345");
        checkoutPage.continueToOverview();

        OverviewPage overviewPage = new OverviewPage(driver);
        overviewPage.finishOrder();
    }
}
