package Functions;

public interface DefaultFunctions {
	public void day();

	public default void month() {
		System.out.println("it is july");
	}
	
}
