package com.simplilearn.metaannotation.JUnitdemo;

public class MetaAnnotationdemo {
@Fast
public void myFastTest() {

}
}
