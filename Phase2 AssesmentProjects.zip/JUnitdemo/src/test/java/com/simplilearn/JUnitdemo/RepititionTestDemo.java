package com.simplilearn.JUnitdemo;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.TestInfo;

public class RepititionTestDemo {

	@RepeatedTest(3)
	public void test1() {
		System.out.println("This is me");
	}
	@RepeatedTest(value=4,name="{displayName}{currentRepetition}/{totalRepetition}")
	@DisplayName("Excecution")
	public void test2(TestInfo testInfo) {
		System.out.println(testInfo.getDisplayName());
	}
	@RepeatedTest(3)
	public void test3(RepetitionInfo repetitionInfo) {
		System.out.println("Current test count"+repetitionInfo.getCurrentRepetition());
	}
}
