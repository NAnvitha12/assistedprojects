package com.simplilearn.JUnitdemo;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals; // Import the static method

public class ArgumentSources {
    @ParameterizedTest
    @CsvSource({ "test, TEST", "monDAY, MONday", "July, july" })
    public void test1(String actual, String expected) {
        String actualValue = actual.toLowerCase();
        String expectedValue = expected.toLowerCase();
        assertEquals(actualValue, expectedValue); // Now, the assertEquals method can be used directly
    }
}
