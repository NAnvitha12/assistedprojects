package com.simplilearn.JUnitdemo;

import java.util.Arrays;
import java.util.Collection;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.function.Executable;

public class DynamicTestsDemo {

    @TestFactory
    public Collection<DynamicTest> dynamicTests() {
        return Arrays.asList(
                DynamicTest.dynamicTest("Simple Test", () -> Assertions.assertTrue(true)),
                DynamicTest.dynamicTest("Executable Class", new MyExecutable()),
                DynamicTest.dynamicTest("Exception Executable", () -> {
                    try {
                        throw new Exception("Exception example");
                    } catch (Exception e) {
                        // Handle the exception here, or it will fail the test
                        e.printStackTrace();
                        Assertions.fail("Exception occurred: " + e.getMessage());
                    }
                }),
                DynamicTest.dynamicTest("Simple Test 2", () -> Assertions.assertTrue(true))
        );
    }
}

class MyExecutable implements Executable {
    @Override
    public void execute() {
        System.out.println("Dynamic Test");
    }
}
