package com.simplilearn.JUnitdemo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


	public class AssertionDemoTest {

	    @Test
	    public void testTrue() {
	        assertTrue(5 > 2);
	    }

	    @Test
	    public void testFalse() {
	        assertFalse(10 < 5);
	    }

	    @Test
	    public void testNotNull() {
	        String name = "John";
	        assertNotNull(name);
	    }

	    @Test
	    public void testNull() {
	        String city = null;
	        assertNull(city);
	    }

	    @Test
	    public void testSame() {
	        String fruit1 = "apple";
	        String fruit2 = "apple";
	        assertSame(fruit1, fruit2);
	    }

	    @Test
	    public void testNotSame() {
	        String car1 = new String("Toyota");
	        String car2 = new String("Toyota");
	        assertNotSame(car1, car2);
	    }

	    @Test
	    public void testArrayEquals() {
	        int[] arr1 = {1, 2, 3};
	        int[] arr2 = {1, 2, 3};
	        assertArrayEquals(arr1, arr2);
	    }
	}
