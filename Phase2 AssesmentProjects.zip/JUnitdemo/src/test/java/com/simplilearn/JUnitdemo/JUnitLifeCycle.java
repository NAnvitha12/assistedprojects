package com.simplilearn.JUnitdemo;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class JUnitLifeCycle {

    @BeforeAll
    public static void setUp() {
        System.out.println("hello");
    }

    @Test
    public void test1() {
        System.out.println("this is me");
    }

    @AfterAll
    public static void tearDown() {
        System.out.println("Bye");
    }
}

