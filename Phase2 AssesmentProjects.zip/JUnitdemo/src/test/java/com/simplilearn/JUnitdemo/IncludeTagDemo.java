package com.simplilearn.JUnitdemo;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.IncludeTags;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
@IncludeTags("production")
public class IncludeTagDemo {

    @Test
    @Tag("development")
    @Tag("production")
    public void test1() {
        // Test code here
    }

    @Test
    @Tag("production")
    public void test2() {
        // Test code here
    }

    @Test
    @Tag("development")
    public void test3() {
        // Test code here
    }
}
