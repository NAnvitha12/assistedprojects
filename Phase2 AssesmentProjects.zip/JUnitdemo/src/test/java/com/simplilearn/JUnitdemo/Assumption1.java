package com.simplilearn.JUnitdemo;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;

public class Assumption1 {

	@Test
	public void test() {
		//assert true ("abc".contains("a"));
		Assumptions.assumeTrue("abc".contains("Z"));
		System.out.println("test1");
	}
	@Test
	public void test2() {
		Assumptions.assumingThat("abc".contains("Z"),()->{
			System.err.println("Friday");
		});
	}
}
