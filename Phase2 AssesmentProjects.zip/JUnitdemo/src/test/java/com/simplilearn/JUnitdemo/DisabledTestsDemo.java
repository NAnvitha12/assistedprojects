package com.simplilearn.JUnitdemo;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

public class DisabledTestsDemo {

    @Test
    public void test1() {
        System.out.println("This is a regular test method.");
      
    }

    @Test
    @Disabled
    public void test2() {
        System.out.println("This test is disabled and won't be executed.");
     
    }

    @Test
   // @Disabled("This test is currently under development.")
    public void test3() {
        System.out.println("This test is disabled with a reason message.");
       
    }
}
