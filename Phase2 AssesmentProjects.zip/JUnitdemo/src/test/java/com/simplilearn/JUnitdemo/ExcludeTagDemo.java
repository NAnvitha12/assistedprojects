package com.simplilearn.JUnitdemo;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.platform.suite.api.ExcludeTags;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.runner.RunWith;
import org.junit.platform.runner.JUnitPlatform;

@RunWith(JUnitPlatform.class)
@ExcludeTags("production")
public class ExcludeTagDemo {

    @Test
    @Tag("development")
    @Tag("production")
    public void test1() {
        // Test code here
    }

    @Test
    @Tag("production")
    public void test2() {
        // Test code here
    }

    @Test
    @Tag("development")
    public void test3() {
        // Test code here
    }
}
