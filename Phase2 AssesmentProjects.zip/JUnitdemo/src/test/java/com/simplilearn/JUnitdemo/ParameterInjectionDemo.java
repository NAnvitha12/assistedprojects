package com.simplilearn.JUnitdemo;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import java.lang.annotation.ElementType;
import java.util.EnumSet;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class ParameterInjectionDemo {

    @ParameterizedTest
    @EnumSource(value = ElementType.class, names = { "TYPE", "METHOD", "FIELD" })
    public void test1(ElementType et) {
        assertTrue(EnumSet.of(ElementType.FIELD, ElementType.TYPE, ElementType.METHOD).contains(et));
    }
}
