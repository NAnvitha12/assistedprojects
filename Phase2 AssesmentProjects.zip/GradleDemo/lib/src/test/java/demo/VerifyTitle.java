package demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class VerifyTitle {

    static WebDriver driver;

    @BeforeAll
    public static void launchApplication() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.linkedin.com/");
    }

    @Test
    public void verifyTitle() {
        // Wait for the title to contain "LinkedIn"
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.titleContains("LinkedIn"));

        String expectedTitle = "LinkedIn: Log In or Sign Up";
        String actualTitle = driver.getTitle();
        System.out.println("Actual Title: " + actualTitle); // Debugging statement
        assertEquals(expectedTitle, actualTitle);
    }
}
