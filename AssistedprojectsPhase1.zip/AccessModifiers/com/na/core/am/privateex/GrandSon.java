package com.na.core.am.privateex;

public class GrandSon {
	private static int GrandSoncredits = 10000;

	public static void main(String[] args) {
		System.out.println(GrandSon.GrandSoncredits);


	}

}
