package com.na.core.am.privateex;

public class GrandDaughter {
	private static int GrandDaughterCredits = 20000;

	public static void main(String[] args) {
		System.out.println(GrandDaughter.GrandDaughterCredits);

	}

}
