package com.na.core.am.publicex;

public class GrandMother {
	public static int GrandMotherCredits = 80000;

	public static void main(String[] args) {
		System.out.println(GrandFather.GrandFatherCredits);

	}

}
