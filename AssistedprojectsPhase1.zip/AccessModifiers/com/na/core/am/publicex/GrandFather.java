package com.na.core.am.publicex;

public class GrandFather {
	public static int GrandFatherCredits = 70000;

	public static void main(String[] args) {
		System.out.println(GrandFather.GrandFatherCredits);

	}

}
