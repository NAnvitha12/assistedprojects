package com.na.core.am.defaultex;

import com.na.core.am.protectedex.Father;

public class Son extends Father {
	static int SonCredits = 30000;

	public static void main(String[] args) {
		System.out.println(Son.SonCredits);
		System.out.println(Father.FatherCredits);

	}

}
