package com.na.core.am.defaultex;

public class Daughter {
	static int DaughterCredits = 40000;

	public static void main(String[] args) {
		System.out.println(Son.SonCredits);

	}

}

