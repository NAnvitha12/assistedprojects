package com.na.core.am.protectedex;

public class Mother {
	protected static int MotherCredits = 60000;

	public static void main(String[] args) {
		System.out.println(Father.FatherCredits);

	}

}
