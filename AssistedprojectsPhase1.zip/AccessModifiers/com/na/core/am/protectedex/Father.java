package com.na.core.am.protectedex;

import com.na.core.am.publicex.GrandFather;

public class Father {
	protected static int FatherCredits = 50000;

	public static void main(String[] args) {
		System.out.println(Father.FatherCredits);
		System.out.println(GrandFather.GrandFatherCredits);

	}

}
