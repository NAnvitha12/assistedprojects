
public class StudentAvegMarks_Example {

	public static void main(String[] args) {
		System.out.println("Strat");
		int marks = 540;
		int subjects = 0;
		float averageMarks = 0;
		boolean isExceptionPresent = false;
		try {
			averageMarks = marks / subjects;
		} catch (ArithmeticException ae) {
			isExceptionPresent = true;
		} finally {
			System.out.println("pleae wait while fetching the result");
		}
		if (isExceptionPresent) {
			System.out.println("service had issue please try again later.......");
		} else {
			System.out.println(averageMarks);
		}
		System.out.println("end");

	}

}
