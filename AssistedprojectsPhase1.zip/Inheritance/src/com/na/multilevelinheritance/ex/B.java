package com.na.multilevelinheritance.ex;

public class B extends D {
	public void month() {
		System.out.println("this is june");
	}

	public static void main(String[] args) {
		B b = new B();
		b.month();
		b.date();
		b.nextYear();
	}
}
