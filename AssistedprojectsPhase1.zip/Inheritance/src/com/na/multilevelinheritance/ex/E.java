package com.na.multilevelinheritance.ex;

public class E {
	public void nextYear() {
		System.out.println("it was 2024");
	}

}
