package com.na.multilevelinheritance.ex;

public class A extends D {
	public void day() {
		System.out.println("today is tuesday");
	}

	public static void main(String[] args) {
		A a = new A();
		a.day();
		a.date();
		a.nextYear();
	}

}
