package com.na.multilevelinheritance.ex;

public class D extends E {
	public void date() {
		System.out.println("today is 27-06-23");
	}

}
