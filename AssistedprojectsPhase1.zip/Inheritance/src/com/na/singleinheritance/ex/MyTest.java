package com.na.singleinheritance.ex;

class Parent {
	void bike() {
		System.out.println("hero");
	}
}

class Child extends Parent {
	void cycle() {
		System.out.println("atluse");
	}

}

public class MyTest {

	public static void main(String[] args) {
		Child child = new Child();
		child.bike();
		child.cycle();
	}

}
