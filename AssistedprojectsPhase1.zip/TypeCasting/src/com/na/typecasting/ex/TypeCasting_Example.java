package com.na.typecasting.ex;

public class TypeCasting_Example {

	public static void main(String[] args) {

		System.out.println("Implicit Type Casting");
		int num = 5;

		float num1 = num;
		System.out.println(num1);

		System.out.println("Explicit Type Casting");

		double num2 = 45.5;
		byte num3 = (byte) num2;
		System.out.println(num3);

	}
}
