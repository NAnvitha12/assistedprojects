package com.na.core.coll.list.ex;

import java.util.LinkedList;
import java.util.List;

public class LinkedList_Example {

	public static void main(String[] args) {
		// 1.I want to hold female student names
		List<String> females = new LinkedList<>();
		females.add("Krishnasri");
		females.add("Navya");
		females.add("Komala");
		females.add("Anvitha");
		females.add("Manisha");
		females.add("Komala");
		females.add(null);
		females.add(null);

		// 2.I want to hold male student names

		List<String> males = new LinkedList<>();
		males.add("Satish");
		males.add("Lakshman");
		males.add("Bhargav");
		males.add("Bharat");
		males.add("Anil");

		// 3. i want to hold feb batch students

		List<String> febstudents = new LinkedList<>();
		febstudents.addAll(males);
		febstudents.addAll(females);
		System.out.println(febstudents);
	}

}
