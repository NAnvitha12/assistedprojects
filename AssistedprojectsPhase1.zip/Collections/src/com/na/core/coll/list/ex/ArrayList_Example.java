package com.na.core.coll.list.ex;

import java.util.ArrayList;
import java.util.List;

public class ArrayList_Example {

	public static void main(String[] args) {
		// 1.I want to hold female student names
		List<String> females = new ArrayList<>();
		females.add("Krishnasri");
		females.add("Navya");
		females.add("Anvitha");
		females.add("Manisha");
		females.add("Komala");
		females.add(null);
		females.add(null);

		// 2.I want to hold male student names

		List<String> males = new ArrayList<>();
		males.add("Satish");
		males.add("Lakshman");
		males.add("Bhargav");
		males.add("Bharat");
		males.add("Anil");

		// 3. i want to hold feb batch students

		List<String> febstudents = new ArrayList<>();
		febstudents.addAll(males);
		febstudents.addAll(females);
		
		System.out.println(febstudents);
	}

}
