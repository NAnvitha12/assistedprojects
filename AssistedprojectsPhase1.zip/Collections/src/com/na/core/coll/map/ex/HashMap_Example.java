package com.na.core.coll.map.ex;

import java.util.HashMap;
import java.util.Map;

public class HashMap_Example {

	public static void main(String[] args) {
		// 1.I want to hold female student names
		Map<String, String> females = new HashMap<>();
		females.put("One", "Krishnasri");
		females.put("Two", "Navya");
		females.put("Three", "Komala");
		females.put("Four", "Anvitha");
		females.put("Five", "Manisha");
		females.put("Three", "Komala");

		// 2.I want to hold male student names

		Map<String, String> males = new HashMap<>();
		males.put("Six", "Satish");
		males.put("Seven", "Lakshman");
		males.put("Eight", "Bhargav");
		males.put("Nine", "Bharat");
		males.put("Ten", "Anil");

		// 3. i want to hold feb batch students

		Map<String, String> febstudents = new HashMap<>();
		febstudents.putAll(males);
		febstudents.putAll(females);
		System.out.println(febstudents);

	}

}
