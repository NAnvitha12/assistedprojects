package com.na.core.coll.set.ex;

import java.util.HashSet;
import java.util.Set;

public class HashSet_Example {

	public static void main(String[] args) {
		// 1.I want to hold female student names
		Set<String> females = new HashSet<>();
		females.add("Krishnasri");
		females.add("Navya");
		females.add("Anvitha");
		females.add("Manisha");
		females.add("Komala");
		females.add(null);
		females.add(null);

		// 2.I want to hold male student names

		Set<String> males = new HashSet<>();
		males.add("Satish");
		males.add("Lakshman");
		males.add("Bhargav");
		males.add("Bharat");
		males.add("Anil");

		// 3. i want to hold feb batch students

		Set<String> febstudents = new HashSet<>();
		febstudents.addAll(males);
		febstudents.addAll(females);
		System.out.println(febstudents);

	}

}
