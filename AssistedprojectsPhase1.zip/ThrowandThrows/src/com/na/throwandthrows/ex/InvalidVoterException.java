package com.na.throwandthrows.ex;

public class InvalidVoterException extends Exception {
	InvalidVoterException(String s){
		super(s);
	}
}
