package com.na.throwandthrows.ex;

public class ValidVoter {

	static void age(int age) throws InvalidVoterException {

	}

	public static void main(String[] args) {
		int age = 22;
		try {
			if (age < 18) {
				throw new InvalidVoterException("not eligible for voting");
			} else {
				System.out.println("eligible for vote");
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		System.out.println("thanks");
	}

}