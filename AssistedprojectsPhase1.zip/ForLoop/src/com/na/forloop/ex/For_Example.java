package com.na.forloop.ex;

public class For_Example {

	public static void main(String[] args) {
		System.out.println("start");
		int sum = 0;
		for (int index = 0; index <= 5; index++) {
			sum = sum + index;
		}
		System.out.println(sum);
		System.out.println("end");

	}

}