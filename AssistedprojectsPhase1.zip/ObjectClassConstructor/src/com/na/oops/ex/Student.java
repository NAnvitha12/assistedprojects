package com.na.oops.ex;

public class Student {

	String name;
	int age;

	// default constructor
	Student() {

	}

	// Constructor
	public Student(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public void displayDetails() {
		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
	}
}
