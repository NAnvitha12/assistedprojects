package com.na.oops.ex;

public class StudentMain {

	public static void main(String[] args) {
		Student student1 = new Student("John", 20);
		Student student2 = new Student("Jane", 22);

		// Displaying details of the students
		System.out.println("Student 1:");
		student1.displayDetails();

		System.out.println("\nStudent 2:");
		student2.displayDetails();
	}

}
