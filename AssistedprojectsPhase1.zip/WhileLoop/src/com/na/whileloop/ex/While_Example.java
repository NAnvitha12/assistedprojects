package com.na.whileloop.ex;

public class While_Example {

	public static void main(String[] args) {
		System.out.println("start");
		int sum = 0;

		int index = 1;

		while (index <= 5) {
			sum = sum + index;

			index++;
		}
		System.out.println(sum);
		System.out.println("end");
	}

}
